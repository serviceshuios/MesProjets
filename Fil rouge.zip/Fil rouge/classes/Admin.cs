/***********************************************************************
 * Module:  Admin.cs
 * Author:  eddy
 * Purpose: Definition of the Class Admin
 ***********************************************************************/

using System;

public class Admin : Personne
{
   public void ModifierClient(Client client)
   {
      // TODO: implement
   }
   
   public void SupprimerClient(Client client)
   {
      // TODO: implement
   }
   
   public int AjouterProduit()
   {
      // TODO: implement
      return 0;
   }
   
   public int ModifierProduit()
   {
      // TODO: implement
      return 0;
   }
   
   public int SupprimerProduit()
   {
      // TODO: implement
      return 0;
   }
   
   public int GererPromotions()
   {
      // TODO: implement
      return 0;
   }
   
   public int AjouterCatalogue()
   {
      // TODO: implement
      return 0;
   }
   
   public int SupprimerCatalogue()
   {
      // TODO: implement
      return 0;
   }
   
   public int ListerCommandes()
   {
      // TODO: implement
      return 0;
   }
   
   public int ModifierEtatCommande()
   {
      // TODO: implement
      return 0;
   }
   
   public int SupprimerCommande()
   {
      // TODO: implement
      return 0;
   }

}