/***********************************************************************
 * Module:  Personne.cs
 * Author:  eddy
 * Purpose: Definition of the Class Personne
 ***********************************************************************/

using System;

public class Personne
{
   public void ModifierPersonne(Personne p)
   {
      // TODO: implement
   }
   
   public void SeConnecter(string login, string mdp)
   {
      // TODO: implement
   }
   
   public void SeDeconnecter()
   {
      // TODO: implement
   }
   
   public Client SenRegistrer(string nom, string prenom, string login, string pass, string email)
   {
      // TODO: implement
      return null;
   }

   public int PersonneID;
   
   public Role role;
   
   /// <pdGenerated>default parent getter</pdGenerated>
   public Role GetRole()
   {
      return role;
   }
   
   /// <pdGenerated>default parent setter</pdGenerated>
   /// <param>newRole</param>
   public void SetRole(Role newRole)
   {
      if (this.role != newRole)
      {
         if (this.role != null)
         {
            Role oldRole = this.role;
            this.role = null;
            oldRole.RemovePersonne(this);
         }
         if (newRole != null)
         {
            this.role = newRole;
            this.role.AddPersonne(this);
         }
      }
   }

   private string Nom;
   private string Prenom;
   private DateTime DateNaissance;
   private string Email;
   private string Telephone;

}