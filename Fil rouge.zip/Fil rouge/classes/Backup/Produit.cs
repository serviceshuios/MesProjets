/***********************************************************************
 * Module:  Produit.cs
 * Author:  eddy
 * Purpose: Definition of the Class Produit
 ***********************************************************************/

using System;

public class Produit
{
   public void Retirer(int qute)
   {
      // TODO: implement
   }
   
   public void Ajouter(int qute)
   {
      // TODO: implement
   }
   
   public void Changer(double prix)
   {
      // TODO: implement
   }
   
   public void AlarmeStockFaible()
   {
      // TODO: implement
   }

   public int IdProduit;
   public string Designation;
   public string Description;
   public Double Prix;
   public int Stock;
   public int StockInitial;
   
   public System.Collections.ArrayList Association2;
   public System.Collections.ArrayList Association5;
   public Catalogue catalogue;
   
   /// <pdGenerated>default parent getter</pdGenerated>
   public Catalogue GetCatalogue()
   {
      return catalogue;
   }
   
   /// <pdGenerated>default parent setter</pdGenerated>
   /// <param>newCatalogue</param>
   public void SetCatalogue(Catalogue newCatalogue)
   {
      if (this.catalogue != newCatalogue)
      {
         if (this.catalogue != null)
         {
            Catalogue oldCatalogue = this.catalogue;
            this.catalogue = null;
            oldCatalogue.RemoveProduit(this);
         }
         if (newCatalogue != null)
         {
            this.catalogue = newCatalogue;
            this.catalogue.AddProduit(this);
         }
      }
   }

}