/***********************************************************************
 * Module:  LigneCommande.cs
 * Author:  eddy
 * Purpose: Definition of the Class LigneCommande
 ***********************************************************************/

using System;

public class LigneCommande
{
   public Produit produitA;
   public Commande commandeB;

   private int Quantite;
   private int Remise;
   private int IdLigneCommande;

}