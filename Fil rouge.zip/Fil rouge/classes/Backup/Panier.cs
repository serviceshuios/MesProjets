/***********************************************************************
 * Module:  Panier.cs
 * Author:  eddy
 * Purpose: Definition of the Class Panier
 ***********************************************************************/

using System;

public class Panier
{
   public void AjouterLigne(int refProduit, int quantite)
   {
      // TODO: implement
   }
   
   public void ModifierLigne(int ref, int quantite)
   {
      // TODO: implement
   }
   
   public void SupprimerLigne(int refProduit)
   {
      // TODO: implement
   }
   
   public void Commander(int refProduit)
   {
      // TODO: implement
   }
   
   public int ViderPanier()
   {
      // TODO: implement
      return 0;
   }

   public System.Collections.ArrayList ligneCommande;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetLigneCommande()
   {
      if (ligneCommande == null)
         ligneCommande = new System.Collections.ArrayList();
      return ligneCommande;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetLigneCommande(System.Collections.ArrayList newLigneCommande)
   {
      RemoveAllLigneCommande();
      foreach (LigneCommande oLigneCommande in newLigneCommande)
         AddLigneCommande(oLigneCommande);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddLigneCommande(LigneCommande newLigneCommande)
   {
      if (newLigneCommande == null)
         return;
      if (this.ligneCommande == null)
         this.ligneCommande = new System.Collections.ArrayList();
      if (!this.ligneCommande.Contains(newLigneCommande))
         this.ligneCommande.Add(newLigneCommande);
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemoveLigneCommande(LigneCommande oldLigneCommande)
   {
      if (oldLigneCommande == null)
         return;
      if (this.ligneCommande != null)
         if (this.ligneCommande.Contains(oldLigneCommande))
            this.ligneCommande.Remove(oldLigneCommande);
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllLigneCommande()
   {
      if (ligneCommande != null)
         ligneCommande.Clear();
   }

   private int NbProduit;
   private int PrixTotal;

}