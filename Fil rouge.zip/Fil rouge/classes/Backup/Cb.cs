/***********************************************************************
 * Module:  Cb.cs
 * Author:  eddy
 * Purpose: Definition of the Class Cb
 ***********************************************************************/

using System;

public class Cb : MoyenPaiement
{
}