/***********************************************************************
 * Module:  Virement.cs
 * Author:  eddy
 * Purpose: Definition of the Class Virement
 ***********************************************************************/

using System;

public class Virement : MoyenPaiement
{
}