/***********************************************************************
 * Module:  Promotion.cs
 * Author:  eddy
 * Purpose: Definition of the Class Promotion
 ***********************************************************************/

using System;

public class Promotion
{
   public void AjouterPromotion(int remise, Produit p)
   {
      // TODO: implement
   }
   
   public void ModifierPromotion(int remise, Produit p)
   {
      // TODO: implement
   }
   
   public void SupprimerPromotion(Produit p)
   {
      // TODO: implement
   }
   
   public System.Array ListerPromotions()
   {
      // TODO: implement
      return null;
   }

   public int IdPromotion;
   public int Promotion;
   
   public System.Collections.ArrayList produit;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetProduit()
   {
      if (produit == null)
         produit = new System.Collections.ArrayList();
      return produit;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetProduit(System.Collections.ArrayList newProduit)
   {
      RemoveAllProduit();
      foreach (Produit oProduit in newProduit)
         AddProduit(oProduit);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddProduit(Produit newProduit)
   {
      if (newProduit == null)
         return;
      if (this.produit == null)
         this.produit = new System.Collections.ArrayList();
      if (!this.produit.Contains(newProduit))
         this.produit.Add(newProduit);
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemoveProduit(Produit oldProduit)
   {
      if (oldProduit == null)
         return;
      if (this.produit != null)
         if (this.produit.Contains(oldProduit))
            this.produit.Remove(oldProduit);
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllProduit()
   {
      if (produit != null)
         produit.Clear();
   }

}