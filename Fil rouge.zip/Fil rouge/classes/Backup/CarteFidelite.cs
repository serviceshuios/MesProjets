/***********************************************************************
 * Module:  CarteFidelite.cs
 * Author:  eddy
 * Purpose: Definition of the Class CarteFidelite
 ***********************************************************************/

using System;

public class CarteFidelite
{
   public void AjouterPoints()
   {
      // TODO: implement
   }

   public int CarteFideliteID;
   
   public Client client;

   private int NbPoints;

}