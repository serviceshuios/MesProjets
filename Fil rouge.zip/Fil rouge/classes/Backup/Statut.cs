/***********************************************************************
 * Module:  Statut.cs
 * Author:  eddy
 * Purpose: Definition of the Class Statut
 ***********************************************************************/

using System;

public class Statut
{
   public System.Collections.ArrayList commande;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetCommande()
   {
      if (commande == null)
         commande = new System.Collections.ArrayList();
      return commande;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetCommande(System.Collections.ArrayList newCommande)
   {
      RemoveAllCommande();
      foreach (Commande oCommande in newCommande)
         AddCommande(oCommande);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddCommande(Commande newCommande)
   {
      if (newCommande == null)
         return;
      if (this.commande == null)
         this.commande = new System.Collections.ArrayList();
      if (!this.commande.Contains(newCommande))
      {
         this.commande.Add(newCommande);
         newCommande.SetStatut(this);      
      }
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemoveCommande(Commande oldCommande)
   {
      if (oldCommande == null)
         return;
      if (this.commande != null)
         if (this.commande.Contains(oldCommande))
         {
            this.commande.Remove(oldCommande);
            oldCommande.SetStatut((Statut)null);
         }
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllCommande()
   {
      if (commande != null)
      {
         System.Collections.ArrayList tmpCommande = new System.Collections.ArrayList();
         foreach (Commande oldCommande in commande)
            tmpCommande.Add(oldCommande);
         commande.Clear();
         foreach (Commande oldCommande in tmpCommande)
            oldCommande.SetStatut((Statut)null);
         tmpCommande.Clear();
      }
   }

   private int StatutID;

}