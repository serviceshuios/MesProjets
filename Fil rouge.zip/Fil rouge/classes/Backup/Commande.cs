/***********************************************************************
 * Module:  Commande.cs
 * Author:  eddy
 * Purpose: Definition of the Class Commande
 ***********************************************************************/

using System;

public class Commande
{
   public int IdCommande;
   public date DateCommande;
   public string ModePaiement;
   public date DatePaiement;
   public string Commentaires;
   
   public System.Collections.ArrayList Association2;
   public Client client;
   
   /// <pdGenerated>default parent getter</pdGenerated>
   public Client GetClient()
   {
      return client;
   }
   
   /// <pdGenerated>default parent setter</pdGenerated>
   /// <param>newClient</param>
   public void SetClient(Client newClient)
   {
      if (this.client != newClient)
      {
         if (this.client != null)
         {
            Client oldClient = this.client;
            this.client = null;
            oldClient.RemoveCommande(this);
         }
         if (newClient != null)
         {
            this.client = newClient;
            this.client.AddCommande(this);
         }
      }
   }
   public Statut statut;
   
   /// <pdGenerated>default parent getter</pdGenerated>
   public Statut GetStatut()
   {
      return statut;
   }
   
   /// <pdGenerated>default parent setter</pdGenerated>
   /// <param>newStatut</param>
   public void SetStatut(Statut newStatut)
   {
      if (this.statut != newStatut)
      {
         if (this.statut != null)
         {
            Statut oldStatut = this.statut;
            this.statut = null;
            oldStatut.RemoveCommande(this);
         }
         if (newStatut != null)
         {
            this.statut = newStatut;
            this.statut.AddCommande(this);
         }
      }
   }

}