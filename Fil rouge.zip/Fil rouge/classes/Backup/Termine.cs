/***********************************************************************
 * Module:  Termine.cs
 * Author:  eddy
 * Purpose: Definition of the Class Termine
 ***********************************************************************/

using System;

public class Termine : Statut
{
}