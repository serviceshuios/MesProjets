/***********************************************************************
 * Module:  Role.cs
 * Author:  eddy
 * Purpose: Definition of the Class Role
 ***********************************************************************/

using System;

public class Role
{
   public int RoleID;
   
   public System.Collections.ArrayList personne;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetPersonne()
   {
      if (personne == null)
         personne = new System.Collections.ArrayList();
      return personne;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetPersonne(System.Collections.ArrayList newPersonne)
   {
      RemoveAllPersonne();
      foreach (Personne oPersonne in newPersonne)
         AddPersonne(oPersonne);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddPersonne(Personne newPersonne)
   {
      if (newPersonne == null)
         return;
      if (this.personne == null)
         this.personne = new System.Collections.ArrayList();
      if (!this.personne.Contains(newPersonne))
      {
         this.personne.Add(newPersonne);
         newPersonne.SetRole(this);      
      }
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemovePersonne(Personne oldPersonne)
   {
      if (oldPersonne == null)
         return;
      if (this.personne != null)
         if (this.personne.Contains(oldPersonne))
         {
            this.personne.Remove(oldPersonne);
            oldPersonne.SetRole((Role)null);
         }
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllPersonne()
   {
      if (personne != null)
      {
         System.Collections.ArrayList tmpPersonne = new System.Collections.ArrayList();
         foreach (Personne oldPersonne in personne)
            tmpPersonne.Add(oldPersonne);
         personne.Clear();
         foreach (Personne oldPersonne in tmpPersonne)
            oldPersonne.SetRole((Role)null);
         tmpPersonne.Clear();
      }
   }

   private string RoleName;

}