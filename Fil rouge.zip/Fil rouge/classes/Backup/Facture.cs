/***********************************************************************
 * Module:  Facture.cs
 * Author:  eddy
 * Purpose: Definition of the Class Facture
 ***********************************************************************/

using System;

public class Facture
{
   public void TelechargerFacture()
   {
      // TODO: implement
   }
   
   public void ImprimerFacture()
   {
      // TODO: implement
   }

   public int FactureID;

   private string FactureNom;

}