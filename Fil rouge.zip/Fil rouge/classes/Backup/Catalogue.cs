/***********************************************************************
 * Module:  Catalogue.cs
 * Author:  eddy
 * Purpose: Definition of the Class Catalogue
 ***********************************************************************/

using System;

public class Catalogue
{
   public System.Array ListerProduits()
   {
      // TODO: implement
      return null;
   }
   
   public System.Array RechercherProduitParMC(string motcle)
   {
      // TODO: implement
      return null;
   }

   public int IdCatalogue;
   public string NomCatalogue;
   public string Description;
   
   public System.Collections.ArrayList produit;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetProduit()
   {
      if (produit == null)
         produit = new System.Collections.ArrayList();
      return produit;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetProduit(System.Collections.ArrayList newProduit)
   {
      RemoveAllProduit();
      foreach (Produit oProduit in newProduit)
         AddProduit(oProduit);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddProduit(Produit newProduit)
   {
      if (newProduit == null)
         return;
      if (this.produit == null)
         this.produit = new System.Collections.ArrayList();
      if (!this.produit.Contains(newProduit))
      {
         this.produit.Add(newProduit);
         newProduit.SetCatalogue(this);      
      }
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemoveProduit(Produit oldProduit)
   {
      if (oldProduit == null)
         return;
      if (this.produit != null)
         if (this.produit.Contains(oldProduit))
         {
            this.produit.Remove(oldProduit);
            oldProduit.SetCatalogue((Catalogue)null);
         }
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllProduit()
   {
      if (produit != null)
      {
         System.Collections.ArrayList tmpProduit = new System.Collections.ArrayList();
         foreach (Produit oldProduit in produit)
            tmpProduit.Add(oldProduit);
         produit.Clear();
         foreach (Produit oldProduit in tmpProduit)
            oldProduit.SetCatalogue((Catalogue)null);
         tmpProduit.Clear();
      }
   }

}