/***********************************************************************
 * Module:  Cheque.cs
 * Author:  eddy
 * Purpose: Definition of the Class Cheque
 ***********************************************************************/

using System;

public class Cheque : MoyenPaiement
{
}