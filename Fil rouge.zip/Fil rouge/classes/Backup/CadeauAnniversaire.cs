/***********************************************************************
 * Module:  CadeauAnniversaire.cs
 * Author:  eddy
 * Purpose: Definition of the Class CadeauAnniversaire
 ***********************************************************************/

using System;

public class CadeauAnniversaire
{
   public int EnvoyerCadeau(int refClient)
   {
      // TODO: implement
      return 0;
   }

   public int CadeauAnniversaireID;
   public string NomCadeau;

}