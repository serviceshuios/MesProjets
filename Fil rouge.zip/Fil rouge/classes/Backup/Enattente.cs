/***********************************************************************
 * Module:  Enattente.cs
 * Author:  eddy
 * Purpose: Definition of the Class Enattente
 ***********************************************************************/

using System;

public class Enattente : Statut
{
}