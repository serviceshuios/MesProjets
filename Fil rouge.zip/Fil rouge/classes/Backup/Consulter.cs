/***********************************************************************
 * Module:  Consulter.cs
 * Author:  eddy
 * Purpose: Definition of the Class Consulter
 ***********************************************************************/

using System;

public class Consulter
{
   public Produit produitA;
   public Client clientB;

   private date DateConsultation;

}