/***********************************************************************
 * Module:  Encours.cs
 * Author:  eddy
 * Purpose: Definition of the Class Encours
 ***********************************************************************/

using System;

public class Encours : Statut
{
}