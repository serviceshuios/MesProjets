/***********************************************************************
 * Module:  Facture.cs
 * Author:  eddy
 * Purpose: Definition of the Class Facture
 ***********************************************************************/

using System;

/// Bon de livraison
public class Bl
{
   public void TelechargerFacture()
   {
      // TODO: implement
   }
   
   public void ImprimerFacture()
   {
      // TODO: implement
   }

   public int BlID;
   public string NomBL;

}