/***********************************************************************
 * Module:  MoyenPaiement.cs
 * Author:  eddy
 * Purpose: Definition of the Class MoyenPaiement
 ***********************************************************************/

using System;

public class MoyenPaiement
{
   public int MoyenpaiementID;
   
   public Client client;
   
   /// <pdGenerated>default parent getter</pdGenerated>
   public Client GetClient()
   {
      return client;
   }
   
   /// <pdGenerated>default parent setter</pdGenerated>
   /// <param>newClient</param>
   public void SetClient(Client newClient)
   {
      if (this.client != newClient)
      {
         if (this.client != null)
         {
            Client oldClient = this.client;
            this.client = null;
            oldClient.RemoveMoyenPaiement(this);
         }
         if (newClient != null)
         {
            this.client = newClient;
            this.client.AddMoyenPaiement(this);
         }
      }
   }

   private string Numero;

}