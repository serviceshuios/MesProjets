/***********************************************************************
 * Module:  Client.cs
 * Author:  eddy
 * Purpose: Definition of the Class Client
 ***********************************************************************/

using System;

public class Client : Personne
{
   public void AjouterCommentaire(string commentaires, Produit p)
   {
      // TODO: implement
   }
   
   public void ConsulterProduit(Produit p)
   {
      // TODO: implement
   }
   
   public void EffectuerPaiement(Commande c, MoyenPaiement m)
   {
      // TODO: implement
   }
   
   public void SuivreCommande(Commande c)
   {
      // TODO: implement
   }
   
   public void ImprimerFacture(int f)
   {
      // TODO: implement
   }
   
   public int CreerCommande()
   {
      // TODO: implement
      return 0;
   }
   
   public int ModifierCommande()
   {
      // TODO: implement
      return 0;
   }
   
   public int DemanderSuppressionCompte()
   {
      // TODO: implement
      return 0;
   }

   public bool Actived;
   public bool Compteasupprimer;
   
   public System.Collections.ArrayList commande;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetCommande()
   {
      if (commande == null)
         commande = new System.Collections.ArrayList();
      return commande;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetCommande(System.Collections.ArrayList newCommande)
   {
      RemoveAllCommande();
      foreach (Commande oCommande in newCommande)
         AddCommande(oCommande);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddCommande(Commande newCommande)
   {
      if (newCommande == null)
         return;
      if (this.commande == null)
         this.commande = new System.Collections.ArrayList();
      if (!this.commande.Contains(newCommande))
      {
         this.commande.Add(newCommande);
         newCommande.SetClient(this);      
      }
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemoveCommande(Commande oldCommande)
   {
      if (oldCommande == null)
         return;
      if (this.commande != null)
         if (this.commande.Contains(oldCommande))
         {
            this.commande.Remove(oldCommande);
            oldCommande.SetClient((Client)null);
         }
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllCommande()
   {
      if (commande != null)
      {
         System.Collections.ArrayList tmpCommande = new System.Collections.ArrayList();
         foreach (Commande oldCommande in commande)
            tmpCommande.Add(oldCommande);
         commande.Clear();
         foreach (Commande oldCommande in tmpCommande)
            oldCommande.SetClient((Client)null);
         tmpCommande.Clear();
      }
   }
   public System.Collections.ArrayList moyenPaiement;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetMoyenPaiement()
   {
      if (moyenPaiement == null)
         moyenPaiement = new System.Collections.ArrayList();
      return moyenPaiement;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetMoyenPaiement(System.Collections.ArrayList newMoyenPaiement)
   {
      RemoveAllMoyenPaiement();
      foreach (MoyenPaiement oMoyenPaiement in newMoyenPaiement)
         AddMoyenPaiement(oMoyenPaiement);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddMoyenPaiement(MoyenPaiement newMoyenPaiement)
   {
      if (newMoyenPaiement == null)
         return;
      if (this.moyenPaiement == null)
         this.moyenPaiement = new System.Collections.ArrayList();
      if (!this.moyenPaiement.Contains(newMoyenPaiement))
      {
         this.moyenPaiement.Add(newMoyenPaiement);
         newMoyenPaiement.SetClient(this);      
      }
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemoveMoyenPaiement(MoyenPaiement oldMoyenPaiement)
   {
      if (oldMoyenPaiement == null)
         return;
      if (this.moyenPaiement != null)
         if (this.moyenPaiement.Contains(oldMoyenPaiement))
         {
            this.moyenPaiement.Remove(oldMoyenPaiement);
            oldMoyenPaiement.SetClient((Client)null);
         }
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllMoyenPaiement()
   {
      if (moyenPaiement != null)
      {
         System.Collections.ArrayList tmpMoyenPaiement = new System.Collections.ArrayList();
         foreach (MoyenPaiement oldMoyenPaiement in moyenPaiement)
            tmpMoyenPaiement.Add(oldMoyenPaiement);
         moyenPaiement.Clear();
         foreach (MoyenPaiement oldMoyenPaiement in tmpMoyenPaiement)
            oldMoyenPaiement.SetClient((Client)null);
         tmpMoyenPaiement.Clear();
      }
   }
   public CarteFidelite carteFidelite;
   public System.Collections.ArrayList cadeauAnniversaire;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetCadeauAnniversaire()
   {
      if (cadeauAnniversaire == null)
         cadeauAnniversaire = new System.Collections.ArrayList();
      return cadeauAnniversaire;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetCadeauAnniversaire(System.Collections.ArrayList newCadeauAnniversaire)
   {
      RemoveAllCadeauAnniversaire();
      foreach (CadeauAnniversaire oCadeauAnniversaire in newCadeauAnniversaire)
         AddCadeauAnniversaire(oCadeauAnniversaire);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddCadeauAnniversaire(CadeauAnniversaire newCadeauAnniversaire)
   {
      if (newCadeauAnniversaire == null)
         return;
      if (this.cadeauAnniversaire == null)
         this.cadeauAnniversaire = new System.Collections.ArrayList();
      if (!this.cadeauAnniversaire.Contains(newCadeauAnniversaire))
         this.cadeauAnniversaire.Add(newCadeauAnniversaire);
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemoveCadeauAnniversaire(CadeauAnniversaire oldCadeauAnniversaire)
   {
      if (oldCadeauAnniversaire == null)
         return;
      if (this.cadeauAnniversaire != null)
         if (this.cadeauAnniversaire.Contains(oldCadeauAnniversaire))
            this.cadeauAnniversaire.Remove(oldCadeauAnniversaire);
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllCadeauAnniversaire()
   {
      if (cadeauAnniversaire != null)
         cadeauAnniversaire.Clear();
   }
   public System.Collections.ArrayList Association5;

}