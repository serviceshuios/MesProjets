/***********************************************************************
 * Module:  Adresse.cs
 * Author:  eddy
 * Purpose: Definition of the Class Adresse
 ***********************************************************************/

using System;

public class Adresse
{
   public int AdresseID;
   public string AdresseNumRue;
   public string AdresseNomRue;
   public string AdresseCP;
   public string AdresseVille;
   
   public System.Collections.ArrayList personne;
   
   /// <pdGenerated>default getter</pdGenerated>
   public System.Collections.ArrayList GetPersonne()
   {
      if (personne == null)
         personne = new System.Collections.ArrayList();
      return personne;
   }
   
   /// <pdGenerated>default setter</pdGenerated>
   public void SetPersonne(System.Collections.ArrayList newPersonne)
   {
      RemoveAllPersonne();
      foreach (Personne oPersonne in newPersonne)
         AddPersonne(oPersonne);
   }
   
   /// <pdGenerated>default Add</pdGenerated>
   public void AddPersonne(Personne newPersonne)
   {
      if (newPersonne == null)
         return;
      if (this.personne == null)
         this.personne = new System.Collections.ArrayList();
      if (!this.personne.Contains(newPersonne))
         this.personne.Add(newPersonne);
   }
   
   /// <pdGenerated>default Remove</pdGenerated>
   public void RemovePersonne(Personne oldPersonne)
   {
      if (oldPersonne == null)
         return;
      if (this.personne != null)
         if (this.personne.Contains(oldPersonne))
            this.personne.Remove(oldPersonne);
   }
   
   /// <pdGenerated>default removeAll</pdGenerated>
   public void RemoveAllPersonne()
   {
      if (personne != null)
         personne.Clear();
   }

}