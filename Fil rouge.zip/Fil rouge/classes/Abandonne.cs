/***********************************************************************
 * Module:  Abandonne.cs
 * Author:  eddy
 * Purpose: Definition of the Class Abandonne
 ***********************************************************************/

using System;

public class Abandonne : Statut
{
}